function population = initPopulation(N,V)
	% Generate the initial population
	population = rand(N,V); %random matrix 
   
end
