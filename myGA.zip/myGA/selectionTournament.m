function selection = selectionTournament(population,NP,V,M)
% populatin has been sorted, now just take the best
	selection = population(1:NP,1:(V));
end
